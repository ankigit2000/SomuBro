﻿using Restaurant.Application.Common.Interfaces;
using Restaurant.Domain.Entities;
using Restaurant.Domain.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurant.Application.Common.Services
{
    public class MenuService : IMenuService
    {
        private readonly IMenuRepository _menuRepository;

        public MenuService(IMenuRepository _menuRepository)
        {
            this._menuRepository = _menuRepository;
        }
        public async Task<RestaurantMenu> AddAsync(RestaurantMenu menu)
        {
            return await _menuRepository.AddAsync(menu);
        }

        public async Task<RestaurantMenu> DeleteAsync(int id)
        {
            return await _menuRepository.DeleteAsync(id);
        }

        public async Task<IEnumerable<RestaurantMenu>> GetAllAsync()
        {
            return await _menuRepository.GetAllAsync();
        }

        public async Task<RestaurantMenu> GetAsync(int id)
        {
            return await _menuRepository.GetAsync(id);
        }

        public async Task<RestaurantMenu> UpdateAsync(int id, RestaurantMenu updated)
        {
            return await _menuRepository.UpdateAsync(id, updated);
        }
    }
}
