﻿using DocumentFormat.OpenXml.Spreadsheet;
using Restaurant.Application.Common.Interfaces;
using Restaurant.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Restaurant.Application.Common.Services
{
    public class UserService : IUserService
    {
        private readonly IUserRepository _userRepository;
        public UserService(IUserRepository _userRepository)
        {
            this._userRepository = _userRepository;
        }
        public Task AddAsync(Domain.Entities.Users Users)
        {
            return _userRepository.AddAsync(Users);
        }

        public Task<Domain.Entities.Users> AuthenticateAsync(string username, string password)
        {
            return _userRepository.AuthenticateAsync(username, password);
        }

        public Task<Domain.Entities.Users> FindByNameAsync(string username)
        {
            return _userRepository.FindByNameAsync(username);
        }

        public Task<Domain.Entities.Users> RegisterAsync(string username, string email, string password, int RoleId)
        {
            return _userRepository.RegisterAsync(username, email, password, RoleId);
        }
    }
}

