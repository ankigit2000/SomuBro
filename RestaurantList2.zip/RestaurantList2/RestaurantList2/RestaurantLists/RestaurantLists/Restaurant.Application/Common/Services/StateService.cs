﻿using Restaurant.Application.Common.Interfaces;
using Restaurant.Domain.Entities;
using Restaurant.Domain.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurant.Application.Common.Services
{
    public class StateService:IStateService
    {
        private readonly IStateRepository _stateRepository;

        public StateService(IStateRepository _stateRepository)
        {
            this._stateRepository = _stateRepository;
        }

        public async Task<RestaurantState> AddAsync(RestaurantState state)
        {
            return await _stateRepository.AddAsync(state);
        }

        public async Task<RestaurantState> DeleteAsync(int id)
        {
            return await _stateRepository.DeleteAsync(id);
        }

        public async Task<IEnumerable<RestaurantState>> GetAllAsync()
        {
            return await _stateRepository.GetAllAsync();
        }

        public async Task<RestaurantState> GetAsync(int id)
        {
            return await _stateRepository.GetAsync(id);
        }

        public async Task<RestaurantState> UpdateAsync(int id, RestaurantState updated)
        {
            return await _stateRepository.UpdateAsync(id, updated);
        }
    }
}
