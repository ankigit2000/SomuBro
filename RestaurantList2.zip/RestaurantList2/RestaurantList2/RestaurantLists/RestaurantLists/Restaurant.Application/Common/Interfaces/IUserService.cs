﻿using Restaurant.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurant.Application.Common.Interfaces
{
    public interface IUserService
    {
        Task<Users> AuthenticateAsync(string username, string password);
        Task AddAsync(Users Users);
        Task<Users> RegisterAsync(string username, string email, string password, int RoleId);

        Task<Users> FindByNameAsync(string username);
    }
}
