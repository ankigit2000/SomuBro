﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurant.Domain.Entities
{
    public class RestaurantMenuItemType
    {
        [Key]
        public int MenuItemTypeID { get; set; }
       public string ItemType { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }

        public IEnumerable<RestaurantMenuItems> MenuItems { get; set; }

      
    }
}
