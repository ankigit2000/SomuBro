﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurant.Domain.Entities
{
    public class User_Roles
    {
        public int User_RolesID { get; set; }

        public int UserID { get; set; }
        public Users Users { get; set; }
        /*[ForeignKey("UserID")]
        public Users User { get; set; }*/

        /*public int RoleID { get; set; }
        [ForeignKey("RoleID")]
        public Role Role { get; set; }*/
    }
}
