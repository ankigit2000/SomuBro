﻿using Restaurant.Domain.Repositories;
using Restaurant.Infrastructure.Persistance.Data;
using Restaurant.Infrastructure.Persistance.Repository.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurant.Infrastructure.Persistance.Repository
{
    public class MenuItemsRepository : Repository<Restaurant.Domain.Entities.RestaurantMenuItems>, IMenuItemsRepository
    {
        private readonly RestaurantDetailsDbContext restaurantDetailsDbContext;

        public MenuItemsRepository(IUnitOfWork unitOfWork) : base(unitOfWork)
        {
        }
    }
}
