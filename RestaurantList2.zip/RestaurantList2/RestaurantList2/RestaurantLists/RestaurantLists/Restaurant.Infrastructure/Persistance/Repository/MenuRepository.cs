﻿using Restaurant.Domain.Repositories;
using Restaurant.Infrastructure.Persistance.Data;
using Restaurant.Infrastructure.Persistance.Repository.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurant.Infrastructure.Persistance.Repository
{
    public class MenuRepository : Repository<Restaurant.Domain.Entities.RestaurantMenu>, IMenuRepository
    {
        private readonly RestaurantDetailsDbContext restaurantDetailsDbContext;

        public MenuRepository(IUnitOfWork unitOfWork) : base(unitOfWork)
        {
        }
    }
}
