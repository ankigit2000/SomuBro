﻿using Restaurant.Infrastructure.Persistance.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurant.Infrastructure.Persistance.Repository
{
    public interface IUnitOfWork : IDisposable
    {
        RestaurantDetailsDbContext RestaurantDetailsDbContext { get; }

        Task<int> CommitAsync();
    }
}
