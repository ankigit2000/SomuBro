﻿using Microsoft.EntityFrameworkCore;
using Restaurant.Domain.Repositories.Base;
using Restaurant.Infrastructure.Persistance.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;

namespace Restaurant.Infrastructure.Persistance.Repository.Base
{
    public class Repository<T> : IRepository<T> where T : class
    {
        private readonly IUnitOfWork _unitOfWork;
       // private RestaurantDetailsDbContext restaurantDetailsDbContext;

        public Repository(IUnitOfWork unitOfWork)
        {
            this._unitOfWork = unitOfWork;
         
        }

   
        public async Task<T> AddAsync(T entity)
        {
            try
            {
                await _unitOfWork.RestaurantDetailsDbContext.Set<T>().AddAsync(entity);
                await _unitOfWork.CommitAsync();
                return entity;
            }
            catch (Exception ex)
            {
                Transaction.Current.Rollback();
                Console.WriteLine(ex.Message);
                return null;
            }
        }
        public async Task<T> DeleteAsync(int id)
        {
            try
            {
                var entity = await _unitOfWork.RestaurantDetailsDbContext.Set<T>().FindAsync(id); if (entity == null)
                {
                    return null;
                }
                _unitOfWork.RestaurantDetailsDbContext.Set<T>().Remove(entity);
                await _unitOfWork.CommitAsync();
                return entity;
            }
            catch (Exception ex)
            {
                Transaction.Current.Rollback();
                Console.WriteLine(ex.Message);
                return null;
            }
        }
        public async Task<IEnumerable<T>> GetAllAsync()
        {
            try
            {
                return await _unitOfWork.RestaurantDetailsDbContext.Set<T>().ToListAsync();
            }
            catch (Exception ex)
            {
                Transaction.Current.Rollback();
                Console.WriteLine(ex.Message);
                return null;
            }
        }
        public async Task<T> GetAsync(int id)
        {
            try
            {
                return await _unitOfWork.RestaurantDetailsDbContext.Set<T>().FindAsync(id);
            }
            catch (Exception ex)
            {
                Transaction.Current.Rollback();
                Console.WriteLine(ex.Message);
                return null;
            }
        }
        public async Task<T> UpdateAsync(int id, T entity)
        {
            try
            {
                var updatedEntity = await _unitOfWork.RestaurantDetailsDbContext.Set<T>().FindAsync(id);
                if (updatedEntity == null)
                {
                    return null;
                }

                //updatedEntity  = entity;
                _unitOfWork.RestaurantDetailsDbContext.Set<T>().Update(entity);
                await _unitOfWork.CommitAsync();
                return entity;
            }
            catch (Exception ex)
            {
                Transaction.Current.Rollback();
                Console.WriteLine(ex.Message);
                return null;
            }
        }
    }
}