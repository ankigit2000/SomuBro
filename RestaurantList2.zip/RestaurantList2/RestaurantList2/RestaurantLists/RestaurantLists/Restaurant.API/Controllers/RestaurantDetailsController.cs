﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Restaurant.Application.Common.Interfaces;

namespace Restaurant.API.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class RestaurantDetailsController : Controller
    {
        private readonly IRestaurantDetailsService restaurantDetailsService;
        private readonly ILoggerManager _logger;


        public RestaurantDetailsController(IRestaurantDetailsService restaurantDetailsService, ILoggerManager _logger)
        {
            this.restaurantDetailsService = restaurantDetailsService;
            this._logger = _logger;
        }
        [HttpGet]
        public async Task<IActionResult> GetAllRestaurantsAsync()
        {
            try
            {
                var restaurants = await restaurantDetailsService.GetAllAsync();
                return Ok(restaurants);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return BadRequest(ex.Message);
            }


        }

        [HttpGet]
        [Route("{id}")]
        [ActionName("GetRestaurantsAsync")]
        public async Task<IActionResult> GetRestaurantsAsync(int id)
        {
            try
            {
                var restaurant = await restaurantDetailsService.GetAsync(id);

                if (restaurant == null)
                {
                    return NotFound();
                }
                return Ok(restaurant);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> AddRestaurantsAsync(Restaurant.Infrastructure.Persistance.DTO.AddRestaurantDetails addRestaurantDetails)
        {
            try
            {
                var restaurants = new Restaurant.Domain.Entities.RestaurantDetails()
                {
                    Restaurant = addRestaurantDetails.Restaurant,
                    Specialities = addRestaurantDetails.Specialities,
                    AdditionalFeatures = addRestaurantDetails.AdditionalFeatures,
                    LocationID = addRestaurantDetails.LocationID,
                    MenuID = addRestaurantDetails.MenuID,
                    UserID = addRestaurantDetails.UserID,
                    UpdatedBy = addRestaurantDetails.UpdatedBy,
                    UpdatedDate = addRestaurantDetails.UpdatedDate

                };
                restaurants = await restaurantDetailsService.AddAsync(restaurants);
                var restaurantDTO = new Restaurant.Infrastructure.Persistance.DTO.RestaurantDetails
                {
                    RestaurantID = restaurants.RestaurantID,
                    Restaurant = restaurants.Restaurant,
                    Specialities = restaurants.Specialities,
                    AdditionalFeatures = restaurants.AdditionalFeatures,
                    LocationID = restaurants.LocationID,
                    MenuID = restaurants.MenuID,
                    UserID = restaurants.UserID,
                    UpdatedBy = restaurants.UpdatedBy,
                    UpdatedDate = restaurants.UpdatedDate

                };
                return CreatedAtAction(nameof(GetRestaurantsAsync), new { id = restaurantDTO.RestaurantID }, restaurantDTO);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return BadRequest(ex.Message);
            }


        }

        [HttpDelete]
        [Route("{id}")]
        public async Task<IActionResult> DeleteRestaurantsAsync(int id)
        {
            try
            {
                var restaurant = await restaurantDetailsService.DeleteAsync(id);
                if (restaurant == null)
                {
                    return NotFound();
                }
                var restaurantDTO = new Restaurant.Infrastructure.Persistance.DTO.RestaurantDetails
                {
                    RestaurantID = restaurant.RestaurantID,
                    Restaurant = restaurant.Restaurant,
                    Specialities = restaurant.Specialities,
                    AdditionalFeatures = restaurant.AdditionalFeatures,
                    UpdatedBy = restaurant.UpdatedBy,
                    UpdatedDate = restaurant.UpdatedDate
                };
                return Ok(restaurantDTO);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return BadRequest(ex.Message);
            }
        }

        [HttpPut]
        [Route("{id}")]
        public async Task<IActionResult> UpdatedRestaurantAsync(int id, [FromBody] Restaurant.Infrastructure.Persistance.DTO.UpdateRestaurantDetails updateRestaurantDetails)
        {
            try
            {
                var restaurant = new Restaurant.Domain.Entities.RestaurantDetails()
                {
                    Restaurant = updateRestaurantDetails.Restaurant,
                    Specialities = updateRestaurantDetails.Specialities,
                    AdditionalFeatures = updateRestaurantDetails.AdditionalFeatures,
                    UpdatedBy = updateRestaurantDetails.UpdatedBy,
                    UpdatedDate = updateRestaurantDetails.UpdatedDate

                };
                restaurant = await restaurantDetailsService.UpdateAsync(id, restaurant);
                if (restaurant == null)
                {
                    return NotFound();
                }
                var restaurantDTO = new Restaurant.Infrastructure.Persistance.DTO.RestaurantDetails()
                {
                    RestaurantID = restaurant.RestaurantID,
                    Restaurant = restaurant.Restaurant,
                    Specialities = restaurant.Specialities,
                    AdditionalFeatures = restaurant.AdditionalFeatures,
                    UpdatedBy = restaurant.UpdatedBy,
                    UpdatedDate = restaurant.UpdatedDate
                };
                return Ok(restaurantDTO);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return BadRequest(ex.Message);
            }

        }
    }
}
