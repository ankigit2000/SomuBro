﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Restaurant.Application.Common.Interfaces;

namespace Restaurant.API.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class MenuItemsController : Controller
    {
        private readonly IMenuItemsService menuItemService;
        private readonly ILoggerManager _logger;
        private readonly IMapper mapper;

        public MenuItemsController(IMenuItemsService menuItemService, IMapper mapper, ILoggerManager _logger)
        {
            this.menuItemService = menuItemService;
            this._logger = _logger;
            this.mapper = mapper;
        }
        [HttpGet]
        public async Task<IActionResult> GetAllMenuItemsAsync()
        {
            try
            {
                var menuItems = await menuItemService.GetAllAsync();
                _logger.LogInfo("Called Get all MenuItems ");
                return Ok(menuItems);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return BadRequest(ex.Message);
            }

        }

        [HttpGet]
        [Route("{id}")]
        [ActionName("GetMenuItemsAsync")]
        public async Task<IActionResult> GetMenuItemsAsync(int id)
        {
            try
            {
                var menuItems = await menuItemService.GetAsync(id);

                if (menuItems == null)
                {
                    return NotFound();
                }
                _logger.LogInfo("Called Get MenuItems by ID ");
                return Ok(menuItems);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> AddMenuItmesAsync(Restaurant.Infrastructure.Persistance.DTO.AddRestaurantMenuItems addRestaurantMenuItems)
        {
            try
            {
                var menuItem = new Restaurant.Domain.Entities.RestaurantMenuItems()
                {
                    ItemName = addRestaurantMenuItems.ItemName,
                    ItemPrice=addRestaurantMenuItems.ItemPrice,
                    MenuItemTypeID = addRestaurantMenuItems.MenuItemTypeID,
                    UpdatedBy = addRestaurantMenuItems.UpdatedBy,
                    UpdatedDate = addRestaurantMenuItems.UpdatedDate
                };

                menuItem = await menuItemService.AddAsync(menuItem);

                var menuItemsDTO = new Restaurant.Infrastructure.Persistance.DTO.RestaurantMenuItems
                {
                    ItemID= menuItem.ItemID,
                    ItemName = menuItem.ItemName,
                    ItemPrice = menuItem.ItemPrice,
                    UpdatedBy = menuItem.UpdatedBy,
                    UpdatedDate = menuItem.UpdatedDate
                };
                _logger.LogInfo("MenuItem is Created");
                return CreatedAtAction(nameof(GetMenuItemsAsync), new { id = menuItemsDTO.ItemID }, menuItemsDTO);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete]
        [Route("{id}")]
        public async Task<IActionResult> DeleteCitiesAsync(int id)
        {
            try
            {
                var menuItem = await menuItemService.DeleteAsync(id); if (menuItem == null)
                {
                    return NotFound();
                }
                var menuItemDTO = new Restaurant.Infrastructure.Persistance.DTO.RestaurantMenuItems
                {
                    ItemID= menuItem.ItemID,
                    ItemName = menuItem.ItemName,
                    ItemPrice = menuItem.ItemPrice,
                    MenuItemTypeID= menuItem.MenuItemTypeID,
                    UpdatedBy = menuItem.UpdatedBy,
                    UpdatedDate = menuItem.UpdatedDate
                };
                _logger.LogInfo("Deleted MenuItem by ID ");
                return Ok(menuItemDTO);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return BadRequest(ex.Message);
            }
        }
        [HttpPut]
        [Route("{id}")]
        public async Task<IActionResult> UpdatedCityAsync(int id, [FromBody] Restaurant.Infrastructure.Persistance.DTO.UpdateRestaurantMenuItems updateRestaurantMenuItems)
        {
            try
            {
                var menuItem = new Restaurant.Domain.Entities.RestaurantMenuItems()
                {
                    ItemName = updateRestaurantMenuItems.ItemName,
                    ItemPrice = updateRestaurantMenuItems.ItemPrice,
                    UpdatedBy = updateRestaurantMenuItems.UpdatedBy,
                    UpdatedDate = updateRestaurantMenuItems.UpdatedDate

                };
                menuItem = await menuItemService.UpdateAsync(id, menuItem);
                if (menuItem == null)
                {
                    return NotFound();
                }
                var menuItemsDTO = new Restaurant.Infrastructure.Persistance.DTO.RestaurantMenuItems()
                {
                    ItemID = menuItem.ItemID,
                    ItemName = menuItem.ItemName,
                    ItemPrice = menuItem.ItemPrice,
                    MenuItemTypeID = menuItem.MenuItemTypeID,
                    UpdatedBy = menuItem.UpdatedBy,
                    UpdatedDate = menuItem.UpdatedDate
                };
                _logger.LogInfo("Updated City");
                return Ok(menuItemsDTO);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return BadRequest(ex.Message);
            }
        }
    }
}
