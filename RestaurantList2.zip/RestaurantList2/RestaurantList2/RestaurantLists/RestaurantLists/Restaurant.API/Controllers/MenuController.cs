﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Restaurant.Application.Common.Interfaces;

namespace Restaurant.API.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class MenuController : Controller
    {
        private readonly IMenuService _MenuService;
        private readonly ILoggerManager _logger;
        private readonly IMapper mapper;

        public MenuController(IMenuService _MenuService, IMapper mapper, ILoggerManager _logger)
        {
            this._MenuService = _MenuService;
            this._logger = _logger;
            this.mapper = mapper;
        }
        [HttpGet]
        public async Task<IActionResult> GetAllMenuAsync()
        {
            try
            {
                var menu = await _MenuService.GetAllAsync();
                _logger.LogInfo("Called Get all Menu List ");
                return Ok(menu);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return BadRequest(ex.Message);
            }

        }

        [HttpGet]
        [Route("{id}")]
        [ActionName("GetMenuAsync")]
        public async Task<IActionResult> GetMenuAsync(int id)
        {
            try
            {
                var menu = await _MenuService.GetAsync(id);

                if (menu == null)
                {
                    return NotFound();
                }
                _logger.LogInfo("Called Get Menu by ID ");
                return Ok(menu);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> AddMenuAsync(Restaurant.Infrastructure.Persistance.DTO.AddMenuRequest addMenuRequest)
        {
            try
            {
                var menu = new Restaurant.Domain.Entities.RestaurantMenu()
                {
                    ItemID= addMenuRequest.ItemID,
                    UpdatedBy = addMenuRequest.UpdatedBy,
                    UpdatedDate = addMenuRequest.UpdatedDate
                };

                menu = await _MenuService.AddAsync(menu);

                var MenuDTO = new Restaurant.Infrastructure.Persistance.DTO.RestaurantMenu
                {
                    MenuID = menu.MenuID,
                    ItemID = menu.ItemID,
                    UpdatedBy = menu.UpdatedBy,
                    UpdatedDate = menu.UpdatedDate
                };
                _logger.LogInfo("Menu Created");
                return CreatedAtAction(nameof(GetMenuAsync), new { id = MenuDTO.MenuID }, MenuDTO);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete]
        [Route("{id}")]
        public async Task<IActionResult> DeleteMenuAsync(int id)
        {
            try
            {
                var menu = await _MenuService.DeleteAsync(id);
                if (menu == null)
                {
                    return NotFound();
                }
                var MenuDTO = new Restaurant.Infrastructure.Persistance.DTO.RestaurantMenu
                {
                    MenuID = menu.MenuID,
                    ItemID= menu.ItemID,
                    UpdatedBy = menu.UpdatedBy,
                    UpdatedDate = menu.UpdatedDate
                };
                _logger.LogInfo("Deleted Menu by ID ");
                return Ok(MenuDTO);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return BadRequest(ex.Message);
            }
        }
        [HttpPut]
        [Route("{id}")]
        public async Task<IActionResult> UpdatedMenuItemTypeyAsync(int id, [FromBody] Restaurant.Infrastructure.Persistance.DTO.UpdateMenu updateMenu)
        {
            try
            {
                var menu = new Restaurant.Domain.Entities.RestaurantMenu()
                {
                    
                    UpdatedBy = updateMenu.UpdatedBy,
                    UpdatedDate = updateMenu.UpdatedDate

                };
                menu = await _MenuService.UpdateAsync(id, menu);
                if (menu == null)
                {
                    return NotFound();
                }
                var MenuDTO = new Restaurant.Infrastructure.Persistance.DTO.RestaurantMenu()
                {
                    MenuID = menu.MenuID,
                    ItemID = menu.ItemID,
                    UpdatedBy = menu.UpdatedBy,
                    UpdatedDate = menu.UpdatedDate
                };
                _logger.LogInfo("Updated City");
                return Ok(MenuDTO);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return BadRequest(ex.Message);
            }

        }
    }
}
