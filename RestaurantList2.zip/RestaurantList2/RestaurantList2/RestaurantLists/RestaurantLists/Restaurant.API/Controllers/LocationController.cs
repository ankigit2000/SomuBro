﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Restaurant.Application.Common.Interfaces;

namespace Restaurant.API.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class LocationController : Controller
    {
        private readonly ILocationService locationService;
        private readonly ILoggerManager _logger;

        public LocationController(ILocationService locationService, ILoggerManager _logger)
        {
            this.locationService= locationService;
            this._logger = _logger;
        }
        [HttpGet]
        public async Task<IActionResult> GetAllLocationsAsync()
        {
            try
            {
                var locations = await locationService.GetAllAsync();
                _logger.LogInfo("Called Get all Location Details ");
                return Ok(locations);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return BadRequest(ex.Message);
            }

        }

        [HttpGet]
        [Route("{id}")]
        [ActionName("GetLocationsAsync")]
        public async Task<IActionResult> GetLocationsAsync(int id)
        {
            try
            {
                var location = await locationService.GetAsync(id);

                if (location == null)
                {
                    return NotFound();
                }
                _logger.LogInfo("Called Get Location Details by ID ");
                return Ok(location);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> AddCitiesAsync(Restaurant.Infrastructure.Persistance.DTO.AddRestaurantLocation addRestaurantLocation)
        {
            try
            {
                if (addRestaurantLocation == null || addRestaurantLocation.Address == null || addRestaurantLocation.CityID == null || addRestaurantLocation.StateID == null)
                {
                    return NotFound();
                }
                //Request to Domain Model
                var location = new Restaurant.Domain.Entities.RestaurantLocation()
                {

                    Address = addRestaurantLocation.Address,
                    CityID = addRestaurantLocation.CityID,
                    StateID = addRestaurantLocation.StateID,
                    UpdatedBy = addRestaurantLocation.UpdatedBy,
                    UpdatedDate = addRestaurantLocation.UpdatedDate

                };
                location = await locationService.AddAsync(location);
                var locationDTO = new Restaurant.Infrastructure.Persistance.DTO.RestaurantLocation
                {
                    LocationID = location.LocationID,
                    Address = location.Address,
                    CityID = location.CityID,
                    StateID = location.StateID,
                    UpdatedBy = location.UpdatedBy,
                    UpdatedDate = location.UpdatedDate

                };
                _logger.LogInfo("Location is  Created");
                return CreatedAtAction(nameof(GetLocationsAsync), new { id = locationDTO.LocationID }, locationDTO);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return BadRequest(ex.Message);
            }

        }

        [HttpDelete]
        [Route("{id}")]
        public async Task<IActionResult> DeleteLocationsAsync(int id)
        {
            try
            {
                var location = await locationService.DeleteAsync(id);
                if (location == null)
                {
                    return NotFound();
                }

                var locationDTO = new Restaurant.Infrastructure.Persistance.DTO.RestaurantLocation
                {
                    LocationID = location.LocationID,
                    Address = location.Address,
                    CityID = location.CityID,
                    StateID = location.StateID,
                    UpdatedBy = location.UpdatedBy,
                    UpdatedDate = location.UpdatedDate
                };
                return Ok(locationDTO);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return BadRequest(ex.Message);
            }
        }
        [HttpPut]
        [Route("{id}")]
        public async Task<IActionResult> UpdatedCityAsync([FromRoute] int id, [FromBody] Restaurant.Infrastructure.Persistance.DTO.UpdateRestaurantLocation updateRestaurantLocation)
        {
            try
            {
                var location = new Restaurant.Domain.Entities.RestaurantLocation()
                {
                    Address = updateRestaurantLocation.Address,
                    UpdatedBy = updateRestaurantLocation.UpdatedBy,
                    UpdatedDate = updateRestaurantLocation.UpdatedDate

                };
                location = await locationService.UpdateAsync(id, location);
                if (location == null)
                {
                    return NotFound();
                }
                var locationDTO = new Restaurant.Infrastructure.Persistance.DTO.RestaurantLocation()
                {
                    LocationID = location.LocationID,
                    Address = location.Address,
                    CityID = location.CityID,
                    StateID = location.StateID,
                    UpdatedBy = location.UpdatedBy,
                    UpdatedDate = location.UpdatedDate
                };
                _logger.LogInfo("Updated Location");
                return Ok(locationDTO);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return BadRequest(ex.Message);
            }

        }
    }
}
