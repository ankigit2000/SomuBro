﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Restaurant.Application.Common.Interfaces;
using Restaurant.Domain.Repositories;

using System.Reflection;

namespace Restaurant.API.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class CityController : Controller 
    {       
            private readonly ICityService cityService;
            private readonly ILoggerManager _logger;
            

            public CityController(ICityService cityService,  ILoggerManager _logger)
            {
                this.cityService = cityService;
                this._logger = _logger;
                
            }
            [HttpGet]
        //[Authorize("RoleName:Admin")]
            public async Task<IActionResult> GetAllCitiesAsync()
            {
                try
                {
                    var cities = await cityService.GetAllAsync();
                    _logger.LogInfo("Called Get all Cities ");
                    return Ok(cities);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex.Message);
                    return BadRequest(ex.Message);
                }

               }

            [HttpGet]
            [Route("{id}")]
            [ActionName("GetCitiesAsync")]
            public async Task<IActionResult> GetCitiesAsync(int id)
            {
            try
            {
                var city = await cityService.GetAsync(id);

                if (city == null)
                {
                    return NotFound();
                }
                _logger.LogInfo("Called Get City by ID ");
                return Ok(city);
            }
            catch (Exception ex) 
            {
                _logger.LogError(ex.Message);
                return BadRequest(ex.Message);
            }      
        }

        [HttpPost]
            public async Task<IActionResult> AddCitiesAsync(Restaurant.Infrastructure.Persistance.DTO.AddCityRequest addCityRequest)
            {
            try
            {
                var city = new Restaurant.Domain.Entities.RestaurantCity()
                {
                    CityName = addCityRequest.CityName,
                    UpdatedBy = addCityRequest.UpdatedBy,
                    UpdatedDate = addCityRequest.UpdatedDate
                };

                city = await cityService.AddAsync(city);

                var cityDTO = new Restaurant.Infrastructure.Persistance.DTO.RestaurantCity
                {
                    CityID = city.CityID,
                    CityName = city.CityName,
                    UpdatedBy = city.UpdatedBy,
                    UpdatedDate = city.UpdatedDate
                };
                _logger.LogInfo("City Created");
                return CreatedAtAction(nameof(GetCitiesAsync), new { id = cityDTO.CityID }, cityDTO);
            }
            catch(Exception ex) 
            {
                _logger.LogError(ex.Message);
                return BadRequest(ex.Message);
            }
            }

            [HttpDelete]
            [Route("{id}")]
            public async Task<IActionResult> DeleteCitiesAsync(int id)
            {
            try
            {
                var city = await cityService.DeleteAsync(id); if (city == null)
                {
                    return NotFound();
                }
                var cityDTO = new Restaurant.Infrastructure.Persistance.DTO.RestaurantCity
                {
                    CityID = city.CityID,
                    CityName = city.CityName,
                    UpdatedBy = city.UpdatedBy,
                    UpdatedDate = city.UpdatedDate
                };
                _logger.LogInfo("Deleted City by ID ");
                return Ok(cityDTO);
            }
            catch(Exception ex)
            {
                _logger.LogError(ex.Message);
                return BadRequest(ex.Message);
            }   
            }
            [HttpPut]
            [Route("{id}")]
            public async Task<IActionResult> UpdatedCityAsync(int id, [FromBody] Restaurant.Infrastructure.Persistance.DTO.UpdateCityRequest updateCityRequest)
            {
            try
            {
                _logger.LogInfo($"Updating City with id: {id}");
                var city = new Restaurant.Domain.Entities.RestaurantCity()
                {
                    CityName = updateCityRequest.CityName,
                    UpdatedBy = updateCityRequest.UpdatedBy,
                    UpdatedDate = updateCityRequest.UpdatedDate

                };
                city = await cityService.GetAsync(id);
                if (city == null)
                {
                    _logger.LogError($"City with id: {id}, not found");
                    return NotFound();
                }
                var cityDTO = new Restaurant.Infrastructure.Persistance.DTO.RestaurantCity()
                {
                    //CityID = city.CityID,
                    CityName = city.CityName,
                    UpdatedBy = city.UpdatedBy,
                    UpdatedDate = city.UpdatedDate
                };
                await cityService.UpdateAsync(id, city);
                _logger.LogInfo("Updated City");
                return Ok(cityDTO);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return BadRequest(ex.Message);
            }

        }


    }
}

